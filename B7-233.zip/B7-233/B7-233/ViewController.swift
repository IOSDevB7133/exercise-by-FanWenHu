//
//  ViewController.swift
//  B7-233
//
//  Created by Apple on 2019/10/8.
//  Copyright © 2019 fwh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var welcome: UILabel!
    
    @IBOutlet weak var user: UITextField!
    
    @IBOutlet weak var hide: UIButton!

    @IBOutlet weak var password: UITextField!
    
    
    
    @IBAction func login(_ sender: Any) {
        if((user.text == "fwh") && (password.text == "123456")){
            if let userID = user.text {
                hide.isHidden = false
                welcome.text = "welcome " + userID
            }
        }else{
            hide.isHidden = true
            welcome.text = "用户名或密码错误"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


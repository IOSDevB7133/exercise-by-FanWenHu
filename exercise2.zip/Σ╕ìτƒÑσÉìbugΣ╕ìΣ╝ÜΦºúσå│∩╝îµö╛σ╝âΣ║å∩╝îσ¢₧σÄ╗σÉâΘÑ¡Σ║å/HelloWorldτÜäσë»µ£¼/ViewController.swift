//
//  ViewController.swift
//  HelloWorld
//
//  Created by fengyuxiang on 2019/8/27.
//  Copyright © 2019 fengyuxiang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var jpgout: UILabel!
    
    @IBOutlet weak var dlorzc: UISegmentedControl!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var id: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBAction func login(_ sender: Any) {
    
        if((id.text == "fwh") && (password.text == "123456")){
            if let userID = id.text {
                hintLabel.isHidden = false
                hintLabel.text = "welcome " + userID
            }
        }else{
            hintLabel.isHidden = false
            hintLabel.text = "ERROR"
        }
    }
    
    
    @IBAction func esc(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}
